import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue import DynamicFrame

def sparkSqlQuery(glueContext, query, mapping, transformation_ctx) -> DynamicFrame:
    for alias, frame in mapping.items():
        frame.toDF().createOrReplaceTempView(alias)
    result = spark.sql(query)
    return DynamicFrame.fromDF(result, glueContext, transformation_ctx)
args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Script generated for node Accelerometer Trusted
AccelerometerTrusted_node1731354184424 = glueContext.create_dynamic_frame.from_catalog(database="stedi11", table_name="accelerometer_trusted", transformation_ctx="AccelerometerTrusted_node1731354184424")

# Script generated for node Customer trusted
Customertrusted_node1731354171857 = glueContext.create_dynamic_frame.from_catalog(database="stedi11", table_name="customer_trusted", transformation_ctx="Customertrusted_node1731354171857")

# Script generated for node Join
Join_node1731357717589 = Join.apply(frame1=AccelerometerTrusted_node1731354184424, frame2=Customertrusted_node1731354171857, keys1=["user"], keys2=["email"], transformation_ctx="Join_node1731357717589")

# Script generated for node SQL Query
SqlQuery8745 = '''
select distinct customerName, email, phone,
birthDay, serialNumber, registrationDate, 
lastUpdateDate, shareWithPublicAsOfDate,
shareWithResearchAsOfDate, shareWithFriendsAsOfDate
from myDataSource;
'''
SQLQuery_node1731357971421 = sparkSqlQuery(glueContext, query = SqlQuery8745, mapping = {"myDataSource":Join_node1731357717589}, transformation_ctx = "SQLQuery_node1731357971421")

# Script generated for node Amazon S3
AmazonS3_node1731354288357 = glueContext.getSink(path="s3://udacity11/customer/curated/", connection_type="s3", updateBehavior="UPDATE_IN_DATABASE", partitionKeys=[], enableUpdateCatalog=True, transformation_ctx="AmazonS3_node1731354288357")
AmazonS3_node1731354288357.setCatalogInfo(catalogDatabase="stedi11",catalogTableName="customer_curated")
AmazonS3_node1731354288357.setFormat("json")
AmazonS3_node1731354288357.writeFrame(SQLQuery_node1731357971421)
job.commit()