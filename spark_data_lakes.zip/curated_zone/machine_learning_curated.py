import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql import functions as SqlFuncs

args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Script generated for node AWS Glue Data Catalog
AWSGlueDataCatalog_node1731360006335 = glueContext.create_dynamic_frame.from_catalog(database="stedi11", table_name="step_trainer_trusted", transformation_ctx="AWSGlueDataCatalog_node1731360006335")

# Script generated for node AWS Glue Data Catalog
AWSGlueDataCatalog_node1731360009051 = glueContext.create_dynamic_frame.from_catalog(database="stedi11", table_name="accelerometer_trusted", transformation_ctx="AWSGlueDataCatalog_node1731360009051")

# Script generated for node Join
Join_node1731360056813 = Join.apply(frame1=AWSGlueDataCatalog_node1731360009051, frame2=AWSGlueDataCatalog_node1731360006335, keys1=["timestamp"], keys2=["sensorreadingtime"], transformation_ctx="Join_node1731360056813")

# Script generated for node Drop Duplicates
DropDuplicates_node1731360083681 =  DynamicFrame.fromDF(Join_node1731360056813.toDF().dropDuplicates(), glueContext, "DropDuplicates_node1731360083681")

# Script generated for node Amazon S3
AmazonS3_node1731360096976 = glueContext.getSink(path="s3://udacity11/step_trainer/machine_learning_curated/", connection_type="s3", updateBehavior="UPDATE_IN_DATABASE", partitionKeys=[], enableUpdateCatalog=True, transformation_ctx="AmazonS3_node1731360096976")
AmazonS3_node1731360096976.setCatalogInfo(catalogDatabase="stedi11",catalogTableName="machine_learning_curated")
AmazonS3_node1731360096976.setFormat("json")
AmazonS3_node1731360096976.writeFrame(DropDuplicates_node1731360083681)
job.commit()