import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue import DynamicFrame

def sparkSqlQuery(glueContext, query, mapping, transformation_ctx) -> DynamicFrame:
    for alias, frame in mapping.items():
        frame.toDF().createOrReplaceTempView(alias)
    result = spark.sql(query)
    return DynamicFrame.fromDF(result, glueContext, transformation_ctx)
args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Script generated for node Step Trainer Landing
StepTrainerLanding_node1731356762155 = glueContext.create_dynamic_frame.from_catalog(database="stedi11", table_name="step_trainer_landing", transformation_ctx="StepTrainerLanding_node1731356762155")

# Script generated for node Customer Curated
CustomerCurated_node1731356764794 = glueContext.create_dynamic_frame.from_catalog(database="stedi11", table_name="customer_curated", transformation_ctx="CustomerCurated_node1731356764794")

# Script generated for node SQL Query
SqlQuery9306 = '''
SELECT step_trainer_landing.sensorreadingtime, 
step_trainer_landing.serialnumber, 
step_trainer_landing.distancefromobject FROM 
step_trainer_landing INNER JOIN customer_curated
ON customer_curated.serialnumber=
step_trainer_landing.serialnumber;
'''
SQLQuery_node1731359165405 = sparkSqlQuery(glueContext, query = SqlQuery9306, mapping = {"step_trainer_landing":StepTrainerLanding_node1731356762155, "customer_curated":CustomerCurated_node1731356764794}, transformation_ctx = "SQLQuery_node1731359165405")

# Script generated for node Amazon S3
AmazonS3_node1731356918198 = glueContext.getSink(path="s3://udacity11/step_trainer/trusted/", connection_type="s3", updateBehavior="UPDATE_IN_DATABASE", partitionKeys=[], enableUpdateCatalog=True, transformation_ctx="AmazonS3_node1731356918198")
AmazonS3_node1731356918198.setCatalogInfo(catalogDatabase="stedi11",catalogTableName="step_trainer_trusted")
AmazonS3_node1731356918198.setFormat("json")
AmazonS3_node1731356918198.writeFrame(SQLQuery_node1731359165405)
job.commit()